package com.infyRail.InfyRail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyRailApplicationTests {

	@Test
	void contextLoads() {
	}

}
